# GGA2404 — Vael-Itha, revision 2026-10-21

The original twin-gondola silhouette, floating foundation and empty coaxial rings
are retained. Neutral steel albedo is moderately darker; SpecTeam R/G retain
environment reflection and sunlight highlights. Old lozenges and zigzag decoration
are replaced with linked concentric ellipses, satellite circles and paired orbital
tracks on the petals, gondolas and ring faces. All colored atlas tiles have a full
army mask; metallic tiles remain neutral. The root bone is named `GGA2404`.

The October 21 revision restores the inward-facing luminous gondola panels by
correcting their face winding, and also corrects the right ring lining's facing.
Both whole gondolas move 0.12 game units toward the center: ring-axis separation
is 1.60 → 1.36 (15 percent). Shell dimensions, ring bores and the centered shot
remain unchanged. Gondola bone origins follow the translated meshes.

All 170 pattern tubes are replaced with surface-projected flat inlays, 1.5 times
their former stroke width. A concave tangent-space normal profile gives shallow
engraved shading. This is a normal-map recess, not a Boolean cut into the metal;
the inlay surface sits 0.0015 units above the receiving skin to avoid z-fighting.
Closed foundation petals and the mirrored left metal ring have outward winding
corrected before projection. The new LODs have 35,454 / 14,210 triangles, compared
with 65,558 / 25,573 in the previous version. `engraved_inlays.py` performs this
projection during regeneration. The prior October 20 revision is preserved in
`archive/before-2026-10-21-inlay-correction.zip`.

## Straight hulls and autonomous recharge

The subsequent October 21 revision holds `hull_values(t).top` at its middle
value, 1.79875, along the entire hull. This removes the inward hooks created by
the former end rise after the 90-degree roll. UV layout, ornamental paths and
all three runtime DDS maps are preserved; the maps were compared byte for byte.
Ring axes, the central shot origin and the fully open 1.36 spacing are retained.

Two native sliders move the complete GondolaL/GondolaR branches 0.42 inward each
when closed. The closest details still have 0.0985 game units of clearance, with
no resizing of the shell or bore. The sliders follow the same yaw/pitch/recoil
parents as the rings. Initial construction starts in the closed pose and begins
charging even without a target. Recharge is an independent unit thread.

After a successfully created projectile, the charge is consumed, the gun holds
open for one simulation tick (0.1 s), and closes over three ticks (0.3 s).
The next orb then grows while the gondolas reopen over 76 ticks (7.6 s).
At the original `RateOfFire = 0.125`, the total post-shot cycle is eight seconds.
The period is sampled from the live weapon rate when a shot succeeds. A complete
charge stays fully open and visible until fired, including while there is no
target or a hold-fire order. Target loss does not cancel the unit recharge.

`MuzzleChargeDelay` is zero: the old target-dependent 2.5-second wait is replaced,
not added to the autonomous cycle. A narrow RackSalvoFiringState gate waits for
`ChargeReady` and checks target/hold-fire before calling the native firing state.
Only a successful native CreateProjectileAtMuzzle starts the next cycle; failure
does not consume the ready orb. Death invalidates the unit thread and clears FX.
The existing full-width mesh field is hidden during closing/partial opening so
it cannot intersect the almost closed gun; the scaled particle charge supplies
electricity during growth. The mesh field returns when fully open.

The preceding accepted version, including its unit script and model sources, is
preserved in `archive/before-2026-10-21-auto-recharge.zip`. Native weapon hook
signatures/state behavior were checked against installed FAF
`lua/sim/weapons/DefaultProjectileWeapon.lua`. Independent charge, ready hold,
failure/success, cancellation and death were checked with mocked APIs outside the
repo. The animation is not yet verified in a FAF match.

## Rebuild

Run `generate_materials.py` with Python, numpy and Pillow, then run Blender 4.5:

```text
python generate_materials.py
blender -b --python generate_turret.py
python preview_scm.py
```

Run from any directory, supplying the paths to these scripts. The scripts find the
mod relative to their own location. They overwrite only this turret's material and
mesh files and its `ball_*` effects. No other mod or installed game directory is
required to generate the model. The baseline PNGs are author-owned source maps.
The stock particle textures are runtime references, not copied game resources.

`generate_turret.py`, `rich_base.py`, `ring_gondolas.py`, and `native_export.py`
adapt the authoring generators from the original standalone turret. Blender is
used directly, without a third-party export addon. SCM sections are aligned to
32 bytes. `GGA2404_source.blend` preserves named objects and rigid bone groups.
`preview_scm.py` adapts this mod's GGA2301 software renderer and reads the exported
SCM. Front, side, overhead and alternate-player-color PNGs approximate lighting;
they are not game screenshots. Charge effects are not drawn by that mesh renderer.

## Centered shot and animation

The Charge, Muzzle and Recoil origins coincide at native coordinates
`(0,54,3.2)`, or `(0,2.7,0.16)` after `UniformScale=0.05`. The ring axis passes
through that point. The existing blueprint references `Muzzle`, so both aim and
projectile creation use the new central position in either LOD. There is no
ChargeSlider or late movement toward the front of the gun. Aim and hover affect
both points through their common parents. Charge rotation has zero local offset.

Runtime hover, field rotation, charge growth and angular recoil remain procedural
Lua animations. Obsolete full-rig SCA clips are archived and removed from runtime;
they keyed aiming bones and are not suitable as decorative animations. No animator
overrides weapon aiming. The saved Blender model is the bind pose.

## Othuy-style orb

The reference is **XSL0402 Othuy**, spawned by XSL0401 Ythotha's death script.
Othuy hides its body and uses `OthuyAmbientEmanation` layers rather than a visible
solid ball. This revision follows that construction using the same native
`electricity_08`, `electricity_09`, `glow_02` and `electricity_beam_02` textures,
with new small-scale emitter configurations and a player-color ramp.
It does not spawn a full experimental unit or inherit its movement/weapon damage.

Both projectile blueprints explicitly use the stock `/meshes/game/nil_mesh`.
The visible orb consists of six particle layers: short arcs, surface flashes,
a soft luminous core, haze, motes and inner electrical flicker. The charging orb
uses the same layers, scaled as charge grows; cancellation destroys its emitters.
The live orb pulses and retains the previous trajectory and ground-hazard logic.

`lua/vael_itha_effects.lua` selects one of the 19 standard FAF lobby army colors
from `ScenarioInfo.ArmySetup`. It sets the verified `RAMPSELECTION_CURVE` emitter
parameter; targeted beams use `SetBeamParam` with STARTCOLOR/ENDCOLOR RGB.
The ramp is 64×256 RGBA without mipmaps, with guarded color bands. Colored sprites
from the old fixed-violet prototype are no longer runtime resources. A custom
palette mod needs the ramp regenerated to match its palette. UI-only recoloring or
late scripted army-color changes are not tracked by this lobby-based FX lookup.

Ground strikes still last 3 seconds, radius 5, six strikes of 400, including own and
allied land units. No target means no long targeted beam. Shield/water fallback
keeps native phason damage but replaces its fixed-color impact particles.
External shield ray interception for direct ground damage remains a prototype
limitation; the change does not introduce a new damage system.

## Reference and verification

Inspected installed FAF XSL0401/XSL0402 scripts, XSL0402 blueprint,
`effecttemplates.lua`, Othuy emitters, phason weapon/projectile classes, GameColors,
simInit and blueprint mesh extraction. Engine effect methods were checked against
[upstream IEffect.lua](https://github.com/FAForever/fa/blob/develop/engine/Sim/IEffect.lua).
The empty mesh is confirmed in installed FAF `meshes.nx2`.

`validation.json` records structural checks and mocked Lua checks, including both
central muzzle positions, open ring bores, masks, DDS decoding and resource paths.
Twelve existing projectile checks were rerun outside the repository against the
new scripts and actual effect helper using engine doubles. They cover strike
timing, friendly damage, moving/dead targets, cancellation, lifetime and cleanup.
No test infrastructure was added to the repository.

**This revision has not been run in a FAF match.** Confirm material brightness,
19-color ramp sampling, particle scale, tracking at steep elevations, central
charge/release, shields and ground damage in game. The previous version was tested
by the user and its feedback prompted these changes.

The full preceding runtime resources are preserved in
`archive/before-2026-10-20-corrections.zip` before replacement.
