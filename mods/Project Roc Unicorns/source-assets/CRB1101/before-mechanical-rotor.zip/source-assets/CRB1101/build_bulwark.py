"""Rebuild the Bulwark crystal projector in game units (Y up)."""
from pathlib import Path
from math import pi, sin, cos
import numpy as np
from PIL import Image

HERE = Path(__file__).resolve().parent
UNIT = HERE.parents[1] / 'units' / 'CRB1101'
from model_geometry import Mesh, MATERIALS, render_scm, load_scm
from supcom_binary import write_scm, save_dds_dxt5


def shell(mesh, outline, levels, angle, material):
    """Extrude a beveled footprint about its own center and rotate around the hub."""
    points = np.array(outline)
    center = points.mean(axis=0)
    rings, centers = [], []
    for y, scale in levels:
        ring = []
        for x, z in center + scale * (points - center):
            ring.append((x*cos(angle)+z*sin(angle), y, z*cos(angle)-x*sin(angle)))
        rings.append(ring)
        centers.append(np.mean(ring, axis=0))
    mesh.loft(rings, centers, material=material)


def geometry(detailed):
    mesh = Mesh(12 if detailed else 8)
    mesh.column([(.45,0),(.51,.055),(.51,.17),(.43,.24)], material='dark')
    mesh.column([(.33,.17),(.33,.32),(.29,.37)], material='armor')
    mesh.column([(.305,.345),(.32,.375),(.32,.40),(.265,.42)], material='edge')
    mesh.column([(.255,.41),(.255,.50)], material='joint')
    mesh.column([(.28,.48),(.295,.505),(.27,.555)], material='steel')
    if detailed:
        for i in range(18):
            angle=2*pi*i/18
            shell(mesh,[(-.012,.246),(.012,.246),(.012,.264),(-.012,.264)],
                  [(.415,1),(.478,1)],angle,'edge')
    foot = [(-.16,.23),(.16,.23),(.28,.47),(.27,.68),(.155,.81),(-.155,.81),(-.27,.68),(-.28,.47)]
    for i in range(3):
        angle = i * 2*pi/3
        shell(mesh, foot, [(0,.92),(.045,1),(.14,1),(.235,.84)], angle, 'armor')
        # Two red armor insets frame the ribbed vent on each foot.
        for hand in (-1,1):
            panel = [(hand*x,z) for x,z in [(.07,.51),(.18,.48),(.215,.59),(.14,.719),(.072,.729)]]
            shell(mesh, panel, [(.232,.94),(.242,1)], angle, 'team')
        if detailed:
            for hand in (-1,1):
                outline=[(hand*.166+.014*cos(j*pi/3),.416+.014*sin(j*pi/3)) for j in range(6)]
                shell(mesh,outline,[(.233,1),(.246,.8)],angle,'steel')
            for z in (.58,.62,.66,.70,.74):
                shell(mesh,[(-.048,z),(.048,z),(.048,z+.015),(-.048,z+.015)],
                      [(.228,1),(.247,.95)], angle,'steel')
        # Separate anchors, shafts and metal tips. All three axes are vertical.
        def tower(radius, levels, material, sides=6):
            if not detailed:
                sides = 4
                levels = [levels[0],levels[-1]]
            outline=[(radius*cos(2*pi*j/sides),.54+radius*sin(2*pi*j/sides)) for j in range(sides)]
            shell(mesh,outline,levels,angle,material)
        tower(.126,[(.22,1),(.30,.92),(.41,.62)],'dark')
        tower(.066,[(.40,1),(.47,.76),(1.40,.50)],'steel',4)
        shell(mesh,[(-.009,.575),(.009,.575),(.007,.588),(-.007,.588)],
              [(.53,1),(1.27,.57)],angle,'team')
        tower(.039,[(1.39,1),(1.47,.76),(1.72,.035)],'edge',4)

    # Offset facet rings break up the reflections like the cut ruby in the reference.
    count = 7 if detailed else 5
    rings = [[(r*cos(2*pi*j/count+phase),y,r*sin(2*pi*j/count+phase)) for j in range(count)]
             for y,r,phase in [(.53,.145,0),(.89,.232,.19),(1.59,.192,-.13)]]
    for lower,upper in zip(rings,rings[1:]):
        for j in range(count):
            k=(j+1)%count
            for tri in [(lower[j],lower[k],upper[j]),(upper[j],lower[k],upper[k])]:
                center=np.mean(tri,axis=0)
                mesh.face(tri,material='crystal' if j%3 else 'lens',outward=(center[0],0,center[2]))
    for j in range(count):
        a,b=rings[-1][j],rings[-1][(j+1)%count]
        mesh.face([a,b,(0,2.15,0)],material='crystal' if j%3 else 'lens',outward=(a[0],.4,a[2]))
    return mesh


def materials():
    # 4 x 2 atlas tiles in the same order as the mesh UV writer.
    palette = {
        'armor': ((59,63,68),(95,100,0,0)), 'dark': ((33,36,42),(70,70,0,0)),
        'edge': ((113,119,126),(145,180,0,0)), 'steel': ((84,89,98),(139,155,0,0)),
        'team': ((106,106,106),(100,140,0,190)), 'crystal': ((208,12,29),(125,212,100,0)),
        'lens': ((154,5,24),(130,205,94,0)), 'joint': ((42,45,47),(83,80,0,0)),
    }
    w,h = 256,128
    maps = [np.zeros((h,w,4),np.uint8) for _ in range(3)]
    y,x = np.mgrid[0:64,0:64]
    noise=np.random.default_rng(1101).normal(0,1.3,(64,64))
    for i,name in enumerate(MATERIALS):
        color, packed=palette[name]
        grain=noise.copy()
        if name in ('crystal','lens'):
            grain += 13*np.sin(x*.038+y*.064) + 19*np.exp(-abs((x+.47*y)%48-25)/1.5)
        if name=='joint':
            grain+=(x%8<2)*22
        region=np.s_[i//4*64:(i//4+1)*64,i%4*64:(i%4+1)*64]
        maps[0][region][:,:,:3]=np.clip(np.array(color)+grain[:,:,None],0,255)
        maps[0][region][:,:,3]=255
        maps[1][region]=packed
        maps[2][region]=(128,128,255,128)
    for data,suffix in zip(maps,['albedo','specteam','normalsTS']):
        save_dds_dxt5(Image.fromarray(data),UNIT/f'CRB1101_{suffix}.dds',independent_channels=True)


if __name__ == '__main__':
    materials()
    for lod in (0,1):
        path=UNIT/f'CRB1101_lod{lod}.scm'
        write_scm(geometry(lod==0),path,['CRB1101'],[-1],[(0,0,0)])
        vertices,faces=load_scm(path)
        assert faces.max()<len(vertices) and np.allclose(np.linalg.norm(vertices[:,3:6],axis=1),1)
        print(path.name, len(vertices),'vertices,',len(faces),'triangles')
    views=[]
    for angle,elev in [(12,19),(60,4),(0,89.9)]:
        views.append(render_scm(UNIT/'CRB1101_lod0.scm',HERE,HERE/'bulwark-preview.png',
                                angle,elev,player=(.85,.025,.045),size=440,texture_prefix='CRB1101'))
    sheet=Image.new('RGB',(440*3,440))
    for i,view in enumerate(views):
        sheet.paste(view,(i*440,0))
    sheet.save(HERE/'bulwark-preview.png')
