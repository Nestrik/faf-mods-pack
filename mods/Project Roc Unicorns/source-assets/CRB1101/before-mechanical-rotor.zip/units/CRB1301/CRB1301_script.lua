local CShieldStructureUnit = import('/lua/cybranunits.lua').CShieldStructureUnit

CRB1301 = Class(CShieldStructureUnit) {}

TypeClass = CRB1301
