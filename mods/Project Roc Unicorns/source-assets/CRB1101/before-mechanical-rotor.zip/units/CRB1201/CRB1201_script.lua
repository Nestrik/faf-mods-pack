local CShieldStructureUnit = import('/lua/cybranunits.lua').CShieldStructureUnit

CRB1201 = Class(CShieldStructureUnit) {}

TypeClass = CRB1201
