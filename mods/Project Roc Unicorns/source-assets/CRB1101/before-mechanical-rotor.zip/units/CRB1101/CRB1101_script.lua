local CShieldStructureUnit = import('/lua/cybranunits.lua').CShieldStructureUnit

CRB1101 = Class(CShieldStructureUnit) {}

TypeClass = CRB1101
